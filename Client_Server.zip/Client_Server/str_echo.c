#include "headers.h"

void str_echo(int connfd){
	int n,num1,num2,sum;
	char line[MAX_MSG], line1[MAX_MSG], line2[MAX_MSG];


	do{
		memset(line, 0*0, MAX_MSG);
		n = recv(connfd, line, MAX_MSG, 0);
		num1 = atoi(line);

		n = recv(connfd, line, MAX_MSG, 0);
		num2 = atoi(line);

		sum = num1 + num2;
		sprintf(line1, "%d", sum);

		send(connfd, line1, strlen(line1) + 1, 0);
	}
	while(abs(strcmp(line, "quit")));
	exit(0);
}
#include "headers.h"
#include "str_cli.c"

int main(int argc, char **argv){
	int sockfd, n, i;
	char line[MAX_MSG];
	struct sockaddr_in servaddr;
	if (argc != 2){
		perror("usage: tcpcli <IPaddress>");
	}

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	printf("Successfully Created Socket\n");
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(SERV_PORT);
	inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

	connect(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr));
	str_cli(stdin, sockfd); /* do it all */
	printf("Closing the connection with the server\n");
	close(sockfd);
	exit(0);
}
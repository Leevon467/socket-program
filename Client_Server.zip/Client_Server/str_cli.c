#include "headers.h"
	
void str_cli(FILE *fp, int sockfd){
	char line[MAX_MSG];
	int n;

	do{
		printf("Enter 1st number :");
		scanf("%s", line);

		send(sockfd, line,strlen(line) + 1, 0);
		printf("data sent (%s)\n", line);

		printf("Enter 2nd number :");
		scanf("%s", line);

		send(sockfd, line,strlen(line) + 1, 0);
		printf("data sent (%s)\n", line);

		n = recv(sockfd, line, MAX_MSG,0);
		printf("Received from server : %s\n", line);
	}
	while(strcmp(line, "quit"));
exit(0);
}

#include "headers.h"
#include "str_echo.c"


int main(int argc, char **argv){
	int listenfd, connfd;
	int n,num1,num2,sum;
	char line[MAX_MSG], line1[MAX_MSG], line2[MAX_MSG];
	pid_t childpid;
	socklen_t clilen;
	struct sockaddr_in cliaddr, servaddr;

	listenfd = socket (AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons (SERV_PORT);

	bind(listenfd, (struct sockaddr *) &servaddr, sizeof(servaddr));
	printf("Bind successful\n");

	listen(listenfd, LISTENQ);
	printf("Listening on port TCP %u\n", SERV_PORT);
	for( ; ; ){
	    clilen = sizeof(cliaddr);
		connfd = accept(listenfd, (struct sockaddr *) &cliaddr, &clilen);
		printf("Received connection from host [IP %s, TCP port %d]\n", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));

		if ((childpid = fork()) == 0){ /*child process*/
			close(listenfd); /*closes listening socket*/
			str_echo(connfd);/*process the request*/
			printf("Closing connection with host [IP %s, TCP port %d]\n", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));
			exit(0);
		}
		close(connfd); /*Parent closes connected socket*/
	}

}
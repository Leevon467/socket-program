#include "unp.h"

int main(int argc, char **argv){
	int sockfd, n, i;
	char line[MAX_MSG];
	struct sockaddr_in servaddr;
	if (argc != 2){
		perror("usage: tcpcli <IPaddress>");
	}

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	printf("Successfully Created Socket\n");
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(SERV_PORT);
	inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

	connect(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr));
	//str_cli(stdin, sockfd); /* do it all */
	do{
		printf("Enter 1st number :");
		scanf("%s", line);

		send(sockfd, line,strlen(line) + 1, 0);
		printf("data sent (%s)\n", line);

		printf("Enter 2nd number :");
		scanf("%s", line);

		send(sockfd, line,strlen(line) + 1, 0);
		printf("data sent (%s)\n", line);

		n = recv(sockfd, line, MAX_MSG,0);
		printf("Received from server : %s\n", line);
	}
	while(strcmp(line, "quit"));

	printf("Closing the connection with the server\n");
	close(sockfd);
	exit(0);
}
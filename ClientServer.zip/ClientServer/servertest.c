#include "unp.h"

int main(int argc, char **argv){
	int listenfd, connfd;
	int n,num1,num2,sum;
	char line[MAX_MSG], line1[MAX_MSG], line2[MAX_MSG];
	pid_t childpid;
	socklen_t clilen;
	struct sockaddr_in cliaddr, servaddr;

	listenfd = socket (AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons (SERV_PORT);

	bind(listenfd, (struct sockaddr *) &servaddr, sizeof(servaddr));
	printf("bind successful\n");

	listen(listenfd, LISTENQ);
	while(1){
		printf("Listening on port TCP %u", SERV_PORT);
	    clilen = sizeof(cliaddr);
		connfd = accept(listenfd, (struct sockaddr *) &cliaddr, &clilen);
		printf("Received connection from host [IP %s, TCP port %d]\n", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));
			do{
				memset(line, 0*0, MAX_MSG);
				n = recv(connfd, line, MAX_MSG, 0);
				num1 = atoi(line);

				n = recv(connfd, line, MAX_MSG, 0);
				num2 = atoi(line);

				sum = num1 + num2;
				sprintf(line1, "%d", sum);

				printf("Received from host [IP %s, TCP port %d] : %s\n", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port), line1);
				send(connfd, line1, strlen(line1) + 1, 0);
			}
			while(abs(strcmp(line, "quit")));

			printf("Closing connection with host [IP %s, TCP port %d]\n", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));

			close(connfd);
	}

}